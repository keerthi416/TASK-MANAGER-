# Smart Task Manager

A full-stack Smart Task Manager application built with Node.js, Express, SQLite, and Vanilla JavaScript. Features real-time client-side deadline monitoring, Web Notifications API desktop screen notifications, and Nodemailer email reminders.

---

## Running Without Localhost (Local IP Access)

You can run and access this app on your local network or laptop without using `localhost` by binding the server to all network interfaces (`0.0.0.0`) and opening the app using your laptop's local IP address.

### 1. Start the Server
Run the following command in your terminal:
```bash
npm start
```
or
```bash
node server.js
```

The server is configured to listen on `0.0.0.0:3000` by default.

---

### 2. Find Your Laptop's Local IP Address

- **Windows:**
  Open Command Prompt or PowerShell and run:
  ```powershell
  ipconfig
  ```
  Look for **IPv4 Address** under your active Wi-Fi or Ethernet adapter (e.g. `192.168.1.15`).

- **macOS:**
  Open Terminal and run:
  ```bash
  ipconfig getifaddr en0
  ```
  *(or check Network Preferences)*

- **Linux:**
  Open Terminal and run:
  ```bash
  ip a
  ```
  or
  ```bash
  hostname -I
  ```

---

### 3. Construct and Open the URL

Once you have your local IPv4 address (e.g., `192.168.1.15`), open your web browser on your laptop or any device on the same local network and navigate to:

```text
http://<YOUR_LOCAL_IP>:3000
```

**Example:**
```text
http://192.168.1.15:3000
```

The frontend dynamically resolves `window.location.origin`, so all API calls (`/api/...`) automatically route to your IP address without hardcoded `localhost` references.

---

### 4. Environment Variables (Optional)

You can customize the host and port in `.env`:

```env
PORT=3000
HOST=0.0.0.0
```

Setting `HOST=0.0.0.0` ensures the server accepts incoming connections from any device on your local network using your local IP.
