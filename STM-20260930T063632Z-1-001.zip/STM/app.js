/**
 * SMART TASK MANAGER - FRONTEND CLIENT ENGINE
 * Real-time client-side task monitoring, Web Notifications API desktop screen notifications,
 * and REST API database integration.
 */

// Dynamic API Base URL resolution - Supports HTTP access via local IP (e.g. http://192.168.x.x:3000), domain, or offline file:// protocol
const IS_STANDALONE = window.location.protocol === 'file:';
const API_BASE_URL = (function() {
  if (IS_STANDALONE) return '';
  if (window.API_BASE_URL) return window.API_BASE_URL;
  return window.location.origin;
})();

// Application State
const state = {
  currentUser: null,
  tasks: [],
  activeFilter: 'all',
  searchQuery: '',
  editingTaskId: null
};

// LocalStorage Fallback Engine (for running standalone without backend server)
function getLocalUsers() {
  try { return JSON.parse(localStorage.getItem('smart_task_local_users') || '[]'); }
  catch (e) { return []; }
}
function saveLocalUsers(users) {
  localStorage.setItem('smart_task_local_users', JSON.stringify(users));
}
function getLocalTasks(email) {
  try { return JSON.parse(localStorage.getItem(`smart_task_tasks_${email}`) || '[]'); }
  catch (e) { return []; }
}
function saveLocalTasks(email, tasks) {
  localStorage.setItem(`smart_task_tasks_${email}`, JSON.stringify(tasks));
}

// DOM Elements
const DOM = {
  // Auth
  authSection: document.getElementById('auth-section'),
  dashboardSection: document.getElementById('dashboard-section'),
  loginForm: document.getElementById('login-form'),
  registerForm: document.getElementById('register-form'),
  loginEmail: document.getElementById('login-email'),
  loginEmailError: document.getElementById('login-email-error'),
  loginPassword: document.getElementById('login-password'),
  loginPassError: document.getElementById('login-pass-error'),
  loginAuthError: document.getElementById('login-auth-error'),
  regName: document.getElementById('reg-name'),
  regNameError: document.getElementById('reg-name-error'),
  regEmail: document.getElementById('reg-email'),
  regEmailError: document.getElementById('reg-email-error'),
  regPassword: document.getElementById('reg-password'),
  regPassError: document.getElementById('reg-pass-error'),
  regAuthError: document.getElementById('reg-auth-error'),
  btnLogout: document.getElementById('btn-logout'),
  userNameDisplay: document.getElementById('user-name-display'),

  // Task Creation
  addTaskForm: document.getElementById('add-task-form'),
  taskTitleInput: document.getElementById('task-title-input'),
  taskPrioritySelect: document.getElementById('task-priority-select'),
  taskDateInput: document.getElementById('task-date-input'),
  taskTimeInput: document.getElementById('task-time-input'),

  // Tasks & Filtering
  searchInput: document.getElementById('search-input'),
  statusFilterSelect: document.getElementById('status-filter-select'),
  taskList: document.getElementById('task-list'),
  emptyState: document.getElementById('empty-state'),

  // Stats Counters
  countTotal: document.getElementById('count-total'),
  countPending: document.getElementById('count-pending'),
  countCompleted: document.getElementById('count-completed'),
  countOverdue: document.getElementById('count-overdue'),

  // Toast Container
  toastContainer: document.getElementById('toast-container')
};

const PASSWORD_ERROR_MSG = "Password must be at least 8 characters long, contain 1 uppercase letter, 1 special character, numbers, and no spaces.";

// ==========================================
// 1. INITIALIZATION & SESSION RESTORATION
// ==========================================
document.addEventListener('DOMContentLoaded', () => {
  initDateInputs();
  loadStoredSession();
  setupEventListeners();
  startTaskMonitoringEngine();
});

function initDateInputs() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  if (DOM.taskDateInput) DOM.taskDateInput.value = `${year}-${month}-${day}`;

  now.setHours(now.getHours() + 2);
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  if (DOM.taskTimeInput) DOM.taskTimeInput.value = `${hours}:${minutes}`;
}

function loadStoredSession() {
  const savedUser = localStorage.getItem('smart_task_logged_user');
  if (savedUser) {
    state.currentUser = JSON.parse(savedUser);
    showDashboard();
  } else {
    DOM.authSection.classList.remove('hidden');
    DOM.dashboardSection.classList.add('hidden');
    DOM.btnLogout.classList.add('hidden');
  }
}

// ==========================================
// 2. WEB NOTIFICATIONS API (DESKTOP POPUPS)
// Requirement 1: Request permission immediately upon login or dashboard load
// ==========================================
function requestDesktopNotificationPermission() {
  if ('Notification' in window) {
    if (Notification.permission === 'default') {
      Notification.requestPermission().then(permission => {
        if (permission === 'granted') {
          showToast('Browser desktop notifications enabled!', 'info');
        }
      });
    }
  }
}

function sendDesktopNotification(title, body, tag) {
  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body: body,
        icon: 'https://cdn-icons-png.flaticon.com/512/906/906334.png',
        tag: tag || 'task-alert',
        requireInteraction: true
      });
    } catch (err) {
      console.log('Desktop notification error:', err);
    }
  }
}

// ==========================================
// 3. FORM VALIDATION & AUTHENTICATION
// ==========================================
function isValidEmail(emailStr) {
  if (!emailStr || typeof emailStr !== 'string') return false;
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return emailRegex.test(emailStr.trim());
}

function isValidPasswordComplexity(passStr) {
  if (!passStr || typeof passStr !== 'string') return false;
  if (passStr.length < 8) return false;
  if (/\s/.test(passStr)) return false; // No spaces allowed
  if (!/[A-Z]/.test(passStr)) return false; // Minimum 1 uppercase
  if (!/[0-9]/.test(passStr)) return false; // Contains numbers
  if (!/[a-zA-Z]/.test(passStr)) return false; // Contains letters
  if (!/[^a-zA-Z0-9]/.test(passStr)) return false; // Minimum 1 special char
  return true;
}

function switchAuthTab(tab) {
  clearAuthErrors();
  if (tab === 'login') {
    DOM.loginForm.classList.remove('hidden');
    DOM.registerForm.classList.add('hidden');
  } else {
    DOM.registerForm.classList.remove('hidden');
    DOM.loginForm.classList.add('hidden');
  }
}

function clearAuthErrors() {
  document.querySelectorAll('.error-message').forEach(el => el.classList.remove('visible'));
  document.querySelectorAll('.form-control').forEach(el => el.classList.remove('is-invalid'));
}

// REGISTER FORM SUBMIT
DOM.registerForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearAuthErrors();

  const nameVal = DOM.regName ? DOM.regName.value.trim() : '';
  const emailVal = DOM.regEmail.value.trim().toLowerCase();
  const passwordVal = DOM.regPassword.value;
  let isValid = true;

  if (!nameVal) {
    if (DOM.regName) DOM.regName.classList.add('is-invalid');
    if (DOM.regNameError) DOM.regNameError.classList.add('visible');
    isValid = false;
  }

  if (!isValidEmail(emailVal)) {
    DOM.regEmail.classList.add('is-invalid');
    DOM.regEmailError.innerText = "Enter a valid E-mail";
    DOM.regEmailError.classList.add('visible');
    isValid = false;
  }

  if (!isValidPasswordComplexity(passwordVal)) {
    DOM.regPassword.classList.add('is-invalid');
    DOM.regPassError.innerText = PASSWORD_ERROR_MSG;
    DOM.regPassError.classList.add('visible');
    isValid = false;
  }

  if (!isValid) return;

  if (IS_STANDALONE || !API_BASE_URL) {
    const users = getLocalUsers();
    if (users.some(u => u.email === emailVal)) {
      DOM.regEmail.classList.add('is-invalid');
      DOM.regEmailError.innerText = "An account with this email already exists.";
      DOM.regEmailError.classList.add('visible');
      return;
    }

    users.push({ name: nameVal, email: emailVal, password: passwordVal });
    saveLocalUsers(users);

    DOM.regName.value = '';
    DOM.regEmail.value = '';
    DOM.regPassword.value = '';

    showToast('Account created successfully! Please login.', 'info');
    switchAuthTab('login');
    DOM.loginEmail.value = emailVal;
    DOM.loginPassword.focus();
    return;
  }

  try {
    const response = await fetch(`${API_BASE_URL}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: nameVal, email: emailVal, password: passwordVal })
    });

    const data = await response.json().catch(() => ({ error: 'Invalid response format from server' }));

    if (!response.ok) {
      const errorMsg = data.error || `Registration failed (HTTP ${response.status})`;
      if (errorMsg.includes('E-mail') || errorMsg.includes('email')) {
        DOM.regEmail.classList.add('is-invalid');
        DOM.regEmailError.innerText = errorMsg;
        DOM.regEmailError.classList.add('visible');
      } else if (errorMsg.includes('Password') || errorMsg.includes('8 characters')) {
        DOM.regPassword.classList.add('is-invalid');
        DOM.regPassError.innerText = errorMsg;
        DOM.regPassError.classList.add('visible');
      } else {
        if (DOM.regAuthError) {
          DOM.regAuthError.innerText = errorMsg;
          DOM.regAuthError.classList.add('visible');
        }
      }
      return;
    }

    DOM.regName.value = '';
    DOM.regEmail.value = '';
    DOM.regPassword.value = '';

    showToast('Account created successfully! Please login with your credentials.', 'info');
    switchAuthTab('login');
    DOM.loginEmail.value = emailVal;
    DOM.loginPassword.focus();

  } catch (err) {
    console.warn('Registration backend unreachable, using browser local storage:', err);
    const users = getLocalUsers();
    if (users.some(u => u.email === emailVal)) {
      DOM.regEmail.classList.add('is-invalid');
      DOM.regEmailError.innerText = "An account with this email already exists.";
      DOM.regEmailError.classList.add('visible');
      return;
    }

    users.push({ name: nameVal, email: emailVal, password: passwordVal });
    saveLocalUsers(users);

    DOM.regName.value = '';
    DOM.regEmail.value = '';
    DOM.regPassword.value = '';

    showToast('Account created successfully! Please login.', 'info');
    switchAuthTab('login');
    DOM.loginEmail.value = emailVal;
    DOM.loginPassword.focus();
  }
});

// LOGIN FORM SUBMIT
DOM.loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearAuthErrors();

  const emailVal = DOM.loginEmail.value.trim().toLowerCase();
  const passwordVal = DOM.loginPassword.value;
  let isValid = true;

  if (!isValidEmail(emailVal)) {
    DOM.loginEmail.classList.add('is-invalid');
    DOM.loginEmailError.innerText = "Enter a valid E-mail";
    DOM.loginEmailError.classList.add('visible');
    isValid = false;
  }

  if (!passwordVal) {
    DOM.loginPassword.classList.add('is-invalid');
    DOM.loginPassError.innerText = "Password is required";
    DOM.loginPassError.classList.add('visible');
    isValid = false;
  }

  if (!isValid) return;

  if (IS_STANDALONE || !API_BASE_URL) {
    const users = getLocalUsers();
    const user = users.find(u => u.email === emailVal);

    if (user) {
      if (user.password !== passwordVal) {
        DOM.loginPassword.classList.add('is-invalid');
        DOM.loginPassError.innerText = "Invalid credentials";
        DOM.loginPassError.classList.add('visible');
        return;
      }
      state.currentUser = { name: user.name, email: user.email };
    } else {
      // Auto-register & authenticate standalone browser user instantly
      const newUser = { name: emailVal.split('@')[0], email: emailVal, password: passwordVal };
      users.push(newUser);
      saveLocalUsers(users);
      state.currentUser = { name: newUser.name, email: newUser.email };
    }

    localStorage.setItem('smart_task_logged_user', JSON.stringify(state.currentUser));
    showDashboard();
    showToast('Welcome to Smart Task Manager!', 'info');
    return;
  }

  try {
    const response = await fetch(`${API_BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: emailVal, password: passwordVal })
    });

    const data = await response.json().catch(() => ({ error: 'Invalid response format from server' }));

    if (!response.ok) {
      DOM.loginEmail.classList.add('is-invalid');
      DOM.loginPassword.classList.add('is-invalid');
      if (DOM.loginAuthError) {
        DOM.loginAuthError.innerText = data.error || `Login failed (HTTP ${response.status})`;
        DOM.loginAuthError.classList.add('visible');
      }
      return;
    }

    state.currentUser = data.user;
    localStorage.setItem('smart_task_logged_user', JSON.stringify(state.currentUser));
    showDashboard();

  } catch (err) {
    console.warn('Login backend unreachable, using browser local storage:', err);
    const users = getLocalUsers();
    const user = users.find(u => u.email === emailVal);

    if (user) {
      if (user.password !== passwordVal) {
        DOM.loginPassword.classList.add('is-invalid');
        DOM.loginPassError.innerText = "Invalid credentials";
        DOM.loginPassError.classList.add('visible');
        return;
      }
      state.currentUser = { name: user.name, email: user.email };
    } else {
      // Auto-register & authenticate offline user for seamless browser mode
      const newUser = { name: emailVal.split('@')[0], email: emailVal, password: passwordVal };
      users.push(newUser);
      saveLocalUsers(users);
      state.currentUser = { name: newUser.name, email: newUser.email };
    }

    localStorage.setItem('smart_task_logged_user', JSON.stringify(state.currentUser));
    showDashboard();
    showToast('Logged in successfully', 'info');
  }
});

// Real-time Input Clearing
if (DOM.regName) {
  DOM.regName.addEventListener('input', () => {
    DOM.regName.classList.remove('is-invalid');
    if (DOM.regNameError) DOM.regNameError.classList.remove('visible');
  });
}
DOM.loginEmail.addEventListener('input', () => {
  DOM.loginEmail.classList.remove('is-invalid');
  DOM.loginEmailError.classList.remove('visible');
  if (DOM.loginAuthError) DOM.loginAuthError.classList.remove('visible');
});
DOM.regEmail.addEventListener('input', () => {
  DOM.regEmail.classList.remove('is-invalid');
  DOM.regEmailError.classList.remove('visible');
  if (DOM.regAuthError) DOM.regAuthError.classList.remove('visible');
});
DOM.regPassword.addEventListener('input', () => {
  if (isValidPasswordComplexity(DOM.regPassword.value)) {
    DOM.regPassword.classList.remove('is-invalid');
    DOM.regPassError.classList.remove('visible');
  }
});

function showDashboard() {
  DOM.authSection.classList.add('hidden');
  DOM.dashboardSection.classList.remove('hidden');
  DOM.btnLogout.classList.remove('hidden');

  DOM.userNameDisplay.innerText = state.currentUser.name || 'User';

  updateNotificationPermissionUIState();

  fetchTasks();
}

DOM.btnLogout.addEventListener('click', () => {
  localStorage.removeItem('smart_task_logged_user');
  state.currentUser = null;
  DOM.dashboardSection.classList.add('hidden');
  DOM.authSection.classList.remove('hidden');
  DOM.btnLogout.classList.add('hidden');
});

// ==========================================
// 4. TASK API & RENDERING
// ==========================================
async function fetchTasks() {
  if (!state.currentUser) return;

  if (IS_STANDALONE || !API_BASE_URL) {
    state.tasks = getLocalTasks(state.currentUser.email);
    renderTasks();
    updateStats();
    return;
  }

  try {
    const res = await fetch(`${API_BASE_URL}/api/tasks?email=${encodeURIComponent(state.currentUser.email)}`, {
      headers: {
        'x-user-email': state.currentUser.email,
        'Content-Type': 'application/json'
      }
    });
    if (res.ok) {
      state.tasks = await res.json();
      saveLocalTasks(state.currentUser.email, state.tasks);
      renderTasks();
      updateStats();
      return;
    }
  } catch (err) {
    console.warn('Fetch tasks backend unreachable, loading local tasks:', err);
  }

  // Local fallback
  state.tasks = getLocalTasks(state.currentUser.email);
  renderTasks();
  updateStats();
}

DOM.addTaskForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const title = DOM.taskTitleInput.value.trim();
  const priority = DOM.taskPrioritySelect.value;
  const dateVal = DOM.taskDateInput.value;
  const timeVal = DOM.taskTimeInput.value;

  if (!title || !dateVal || !timeVal) return;

  const dueTimestamp = new Date(`${dateVal}T${timeVal}:00`).toISOString();

  if (IS_STANDALONE || !API_BASE_URL) {
    if (state.editingTaskId) {
      const taskIndex = state.tasks.findIndex(t => String(t.id) === String(state.editingTaskId));
      if (taskIndex !== -1) {
        state.tasks[taskIndex].title = title;
        state.tasks[taskIndex].priority = priority;
        state.tasks[taskIndex].dueTimestamp = dueTimestamp;
        state.tasks[taskIndex].targetTime = dueTimestamp;
      }
      state.editingTaskId = null;
      showToast(`Task "${title}" updated successfully!`, 'info');
    } else {
      const newTask = {
        id: 'task_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
        user_email: state.currentUser ? state.currentUser.email : '',
        title: title,
        priority: priority,
        dueTimestamp: dueTimestamp,
        targetTime: dueTimestamp,
        completed: 0,
        status: 'pending'
      };
      state.tasks.unshift(newTask);
      showToast(`Task "${title}" created successfully!`, 'info');
    }

    DOM.taskTitleInput.value = '';
    initDateInputs();
    updateTaskFormUIState();
    if (state.currentUser) {
      saveLocalTasks(state.currentUser.email, state.tasks);
    }
    renderTasks();
    updateStats();
    return;
  }

  try {
    if (state.editingTaskId) {
      // UPDATE EXISTING TASK (PUT)
      const res = await fetch(`${API_BASE_URL}/api/tasks/${state.editingTaskId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'x-user-email': state.currentUser ? state.currentUser.email : ''
        },
        body: JSON.stringify({
          title: title,
          priority: priority,
          dueTimestamp: dueTimestamp,
          targetTime: dueTimestamp
        })
      });

      if (res.ok) {
        state.editingTaskId = null;
        DOM.taskTitleInput.value = '';
        initDateInputs();
        updateTaskFormUIState();
        showToast(`Task "${title}" updated successfully!`, 'info');
        fetchTasks();
        return;
      }
    } else {
      // CREATE NEW TASK (POST)
      const res = await fetch(`${API_BASE_URL}/api/tasks`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-email': state.currentUser ? state.currentUser.email : ''
        },
        body: JSON.stringify({
          user_email: state.currentUser.email,
          title: title,
          priority: priority,
          dueTimestamp: dueTimestamp,
          targetTime: dueTimestamp
        })
      });

      if (res.ok) {
        DOM.taskTitleInput.value = '';
        initDateInputs();
        showToast(`Task "${title}" created successfully!`, 'info');
        fetchTasks();
        return;
      }
    }
  } catch (err) {
    console.warn('Save task API unreachable, processing locally in browser mode:', err);
  }

  // Local fallback for add/edit task
  if (state.editingTaskId) {
    const taskIndex = state.tasks.findIndex(t => String(t.id) === String(state.editingTaskId));
    if (taskIndex !== -1) {
      state.tasks[taskIndex].title = title;
      state.tasks[taskIndex].priority = priority;
      state.tasks[taskIndex].dueTimestamp = dueTimestamp;
      state.tasks[taskIndex].targetTime = dueTimestamp;
    }
    state.editingTaskId = null;
    showToast(`Task "${title}" updated successfully!`, 'info');
  } else {
    const newTask = {
      id: 'task_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      user_email: state.currentUser ? state.currentUser.email : '',
      title: title,
      priority: priority,
      dueTimestamp: dueTimestamp,
      targetTime: dueTimestamp,
      completed: 0,
      status: 'pending'
    };
    state.tasks.unshift(newTask);
    showToast(`Task "${title}" created successfully!`, 'info');
  }

  DOM.taskTitleInput.value = '';
  initDateInputs();
  updateTaskFormUIState();
  if (state.currentUser) {
    saveLocalTasks(state.currentUser.email, state.tasks);
  }
  renderTasks();
  updateStats();
});

function editTask(taskId) {
  const task = state.tasks.find(t => String(t.id) === String(taskId));
  if (!task) return;

  state.editingTaskId = taskId;

  if (DOM.taskTitleInput) DOM.taskTitleInput.value = task.title;
  if (DOM.taskPrioritySelect) DOM.taskPrioritySelect.value = task.priority || 'Medium';

  const dueIso = task.targetTime || task.dueTimestamp;
  if (dueIso) {
    const dt = new Date(dueIso);
    const year = dt.getFullYear();
    const month = String(dt.getMonth() + 1).padStart(2, '0');
    const day = String(dt.getDate()).padStart(2, '0');
    const hours = String(dt.getHours()).padStart(2, '0');
    const minutes = String(dt.getMinutes()).padStart(2, '0');

    if (DOM.taskDateInput) DOM.taskDateInput.value = `${year}-${month}-${day}`;
    if (DOM.taskTimeInput) DOM.taskTimeInput.value = `${hours}:${minutes}`;
  }

  updateTaskFormUIState();
  if (DOM.taskTitleInput) {
    DOM.taskTitleInput.focus();
    DOM.taskTitleInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
  showToast(`Editing task: "${task.title}"`, 'info');
  renderTasks();
}

function cancelEditTask() {
  state.editingTaskId = null;
  if (DOM.taskTitleInput) DOM.taskTitleInput.value = '';
  initDateInputs();
  updateTaskFormUIState();
  showToast('Edit cancelled.', 'info');
  renderTasks();
}

function updateTaskFormUIState() {
  const submitBtn = DOM.addTaskForm ? DOM.addTaskForm.querySelector('button[type="submit"]') : null;
  let cancelBtn = document.getElementById('btn-cancel-edit');

  if (state.editingTaskId) {
    if (submitBtn) {
      submitBtn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Update Task';
      submitBtn.classList.remove('btn-primary');
      submitBtn.classList.add('btn-success');
    }
    if (!cancelBtn && DOM.addTaskForm) {
      cancelBtn = document.createElement('button');
      cancelBtn.type = 'button';
      cancelBtn.id = 'btn-cancel-edit';
      cancelBtn.className = 'btn btn-secondary btn-cancel-edit';
      cancelBtn.innerHTML = '<i class="fa-solid fa-xmark"></i> Cancel';
      cancelBtn.onclick = cancelEditTask;
      const btnCol = DOM.addTaskForm.querySelector('.task-btn-col');
      if (btnCol) btnCol.appendChild(cancelBtn);
    } else if (cancelBtn) {
      cancelBtn.classList.remove('hidden');
    }
  } else {
    if (submitBtn) {
      submitBtn.innerHTML = '<i class="fa-solid fa-plus"></i> Add Task';
      submitBtn.classList.remove('btn-success');
      submitBtn.classList.add('btn-primary');
    }
    if (cancelBtn) {
      cancelBtn.classList.add('hidden');
    }
  }
}

async function toggleTaskComplete(taskId) {
  if (IS_STANDALONE || !API_BASE_URL) {
    const task = state.tasks.find(t => String(t.id) === String(taskId));
    if (task) {
      task.completed = task.completed ? 0 : 1;
      if (task.completed) task.status = 'completed';
      else task.status = 'pending';
      if (state.currentUser) {
        saveLocalTasks(state.currentUser.email, state.tasks);
      }
      if (state.activeOverdueTask && String(state.activeOverdueTask.id) === String(taskId)) {
        closeOverdueModal();
      }
      renderTasks();
      updateStats();
    }
    return;
  }

  try {
    const res = await fetch(`${API_BASE_URL}/api/tasks/${taskId}/toggle`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'x-user-email': state.currentUser ? state.currentUser.email : ''
      }
    });
    if (res.ok) {
      if (state.activeOverdueTask && String(state.activeOverdueTask.id) === String(taskId)) {
        closeOverdueModal();
      }
      fetchTasks();
      return;
    }
  } catch (err) {
    console.warn('Toggle task API unreachable, updating locally:', err);
  }

  // Local fallback
  const task = state.tasks.find(t => String(t.id) === String(taskId));
  if (task) {
    task.completed = task.completed ? 0 : 1;
    if (task.completed) task.status = 'completed';
    else task.status = 'pending';
    if (state.currentUser) {
      saveLocalTasks(state.currentUser.email, state.tasks);
    }
    if (state.activeOverdueTask && String(state.activeOverdueTask.id) === String(taskId)) {
      closeOverdueModal();
    }
    renderTasks();
    updateStats();
  }
}

async function deleteTask(taskId) {
  if (IS_STANDALONE || !API_BASE_URL) {
    state.tasks = state.tasks.filter(t => String(t.id) !== String(taskId));
    if (state.currentUser) {
      saveLocalTasks(state.currentUser.email, state.tasks);
    }
    if (state.activeOverdueTask && String(state.activeOverdueTask.id) === String(taskId)) {
      closeOverdueModal();
    }
    if (state.editingTaskId === taskId) {
      cancelEditTask();
    }
    showToast('Task removed successfully.', 'warning');
    renderTasks();
    updateStats();
    return;
  }

  try {
    const res = await fetch(`${API_BASE_URL}/api/tasks/${taskId}`, {
      method: 'DELETE',
      headers: {
        'x-user-email': state.currentUser ? state.currentUser.email : ''
      }
    });
    if (res.ok) {
      if (state.activeOverdueTask && String(state.activeOverdueTask.id) === String(taskId)) {
        closeOverdueModal();
      }
      if (state.editingTaskId === taskId) {
        cancelEditTask();
      }
      showToast('Task removed successfully.', 'warning');
      fetchTasks();
      return;
    }
  } catch (err) {
    console.warn('Delete task API unreachable, removing locally:', err);
  }

  // Local fallback
  state.tasks = state.tasks.filter(t => String(t.id) !== String(taskId));
  if (state.currentUser) {
    saveLocalTasks(state.currentUser.email, state.tasks);
  }
  if (state.activeOverdueTask && String(state.activeOverdueTask.id) === String(taskId)) {
    closeOverdueModal();
  }
  if (state.editingTaskId === taskId) {
    cancelEditTask();
  }
  showToast('Task removed successfully.', 'warning');
  renderTasks();
  updateStats();
}

DOM.searchInput.addEventListener('input', (e) => {
  state.searchQuery = e.target.value.toLowerCase().trim();
  renderTasks();
});

DOM.statusFilterSelect.addEventListener('change', (e) => {
  state.activeFilter = e.target.value;
  renderTasks();
});

function renderTasks() {
  const filtered = state.tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(state.searchQuery);
    let matchesFilter = true;

    if (state.activeFilter === 'pending') {
      matchesFilter = !task.completed && task.status !== 'overdue';
    } else if (state.activeFilter === 'completed') {
      matchesFilter = task.completed;
    } else if (state.activeFilter === 'overdue') {
      matchesFilter = !task.completed && task.status === 'overdue';
    } else if (state.activeFilter === 'high') {
      matchesFilter = task.priority === 'High';
    }

    return matchesSearch && matchesFilter;
  });

  DOM.taskList.innerHTML = '';

  if (filtered.length === 0) {
    DOM.emptyState.classList.remove('hidden');
    return;
  }

  DOM.emptyState.classList.add('hidden');

  filtered.forEach(task => {
    const taskEl = document.createElement('div');
    const isOverdue = !task.completed && task.status === 'overdue';
    const isEditing = state.editingTaskId === task.id;
    taskEl.className = `task-item ${task.completed ? 'completed' : ''} ${isOverdue ? 'overdue' : ''} ${isEditing ? 'is-editing' : ''}`;
    taskEl.setAttribute('data-task-id', task.id);

    const formattedDate = formatDueDate(task.targetTime || task.dueTimestamp);
    const priorityClass = `badge-${(task.priority || 'Medium').toLowerCase()}`;

    taskEl.innerHTML = `
      <div class="task-top-row">
        <div class="task-left">
          <input type="checkbox" class="task-checkbox" ${task.completed ? 'checked' : ''} onchange="toggleTaskComplete('${task.id}')" title="Toggle completion">
          <div class="task-details">
            <span class="task-title">${escapeHtml(task.title)}</span>
            <div class="task-meta">
              <span class="badge ${priorityClass}">${task.priority || 'Medium'}</span>
              <span class="task-time-badge"><i class="fa-regular fa-clock"></i> ${formattedDate}</span>
              ${isOverdue ? '<span class="badge badge-status overdue"><i class="fa-solid fa-triangle-exclamation"></i> Overdue</span>' : ''}
              ${task.completed ? '<span class="badge badge-status completed"><i class="fa-solid fa-check"></i> Completed</span>' : ''}
              ${isEditing ? '<span class="badge badge-editing"><i class="fa-solid fa-pen"></i> Editing...</span>' : ''}
            </div>
          </div>
        </div>
      </div>
      <div class="task-actions-row">
        <button class="btn btn-action btn-action-complete ${task.completed ? 'is-completed' : ''}" onclick="toggleTaskComplete('${task.id}')" title="${task.completed ? 'Mark Incomplete' : 'Mark Complete'}">
          <i class="fa-solid ${task.completed ? 'fa-rotate-left' : 'fa-check'}"></i> ${task.completed ? 'Completed' : 'Complete'}
        </button>
        <button class="btn btn-action btn-action-edit" onclick="editTask('${task.id}')" title="Edit Task Details">
          <i class="fa-solid fa-pen-to-square"></i> Edit
        </button>
        <button class="btn btn-action btn-action-delete" onclick="deleteTask('${task.id}')" title="Delete Task">
          <i class="fa-solid fa-xmark"></i> Delete
        </button>
      </div>
    `;

    DOM.taskList.appendChild(taskEl);
  });
}

function updateStats() {
  const total = state.tasks.length;
  const completed = state.tasks.filter(t => t.completed).length;
  const overdue = state.tasks.filter(t => !t.completed && t.status === 'overdue').length;
  const pending = state.tasks.filter(t => !t.completed && t.status !== 'overdue').length;

  DOM.countTotal.innerText = total;
  DOM.countPending.innerText = pending;
  DOM.countCompleted.innerText = completed;
  DOM.countOverdue.innerText = overdue;

  const percent = total > 0 ? Math.round((completed / total) * 100) : 0;
  const progressBar = document.getElementById('progress-bar-fill');
  const progressText = document.getElementById('progress-percent');
  if (progressBar) progressBar.style.width = `${percent}%`;
  if (progressText) progressText.innerText = `${percent}%`;
}

function formatDueDate(isoStr) {
  if (!isoStr) return '';
  const dateObj = new Date(isoStr);
  const now = new Date();
  const isToday = dateObj.toDateString() === now.toDateString();

  const timeString = dateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  if (isToday) return `Today at ${timeString}`;
  const dateString = dateObj.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
  return `${dateString} at ${timeString}`;
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>"']/g, match => {
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
    return map[match];
  });
}

// ==========================================
// 5. FIREBASE CLOUD MESSAGING (FCM) & DESKTOP BACKGROUND NOTIFICATIONS
// ==========================================

const firebaseConfig = {
  apiKey: "AIzaSy_SmartTaskManager_FCM_Key",
  authDomain: "smart-task-manager.firebaseapp.com",
  projectId: "smart-task-manager",
  storageBucket: "smart-task-manager.appspot.com",
  messagingSenderId: "1035469915969",
  appId: "1:1035469915969:web:smarttaskmanager"
};

let fcmMessaging = null;

function initFirebaseMessaging() {
  try {
    if (typeof firebase !== 'undefined' && firebase.apps) {
      if (!firebase.apps.length) {
        firebase.initializeApp(firebaseConfig);
      }
      if (firebase.messaging.isSupported()) {
        fcmMessaging = firebase.messaging();
        fcmMessaging.onMessage((payload) => {
          console.log('[App] Foreground FCM notification received:', payload);
          const title = payload.notification?.title || payload.data?.title || 'Task Reminder';
          const body = payload.notification?.body || payload.data?.body || 'Task update';
          showToast(`${title}: ${body}`, 'info');
        });
      }
    }
  } catch (err) {
    console.warn('[FCM] Firebase Messaging setup warning:', err);
  }
}

/**
 * Handles all browser Notification Permission states:
 * - 'granted': Register FCM / push token with backend and update UI
 * - 'denied': Do not repeatedly ask for permission; show clear UI instructions
 * - 'default': Show button to enable notifications
 * - Unsupported: Indicate unsupported browser feature
 */
function updateNotificationPermissionUIState() {
  const btnEnablePush = document.getElementById('btn-enable-push');
  const noticeTag = document.querySelector('.email-notice-tag');

  if (!('Notification' in window) || !('serviceWorker' in navigator)) {
    if (btnEnablePush) {
      btnEnablePush.innerHTML = '<i class="fa-solid fa-bell-slash"></i> Push Unsupported';
      btnEnablePush.disabled = true;
    }
    if (noticeTag) {
      noticeTag.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> Desktop Notifications Unsupported';
    }
    return;
  }

  const statePermission = Notification.permission;

  if (statePermission === 'granted') {
    if (btnEnablePush) {
      btnEnablePush.innerHTML = '<i class="fa-solid fa-bell"></i> FCM Push Active';
      btnEnablePush.classList.remove('btn-header-pill');
      btnEnablePush.classList.add('btn-success-pill');
    }
    if (noticeTag) {
      noticeTag.innerHTML = '<i class="fa-solid fa-bell"></i> Real-Time FCM Desktop Notifications Active';
    }
    if (state.currentUser) {
      registerPushSubscriptionToken(false);
    }
  } else if (statePermission === 'denied') {
    if (btnEnablePush) {
      btnEnablePush.innerHTML = '<i class="fa-solid fa-bell-slash"></i> Notifications Blocked';
      btnEnablePush.classList.add('btn-warning-pill');
    }
    if (noticeTag) {
      noticeTag.innerHTML = '<i class="fa-solid fa-lock"></i> Notifications Denied in Browser Settings';
    }
  } else {
    if (btnEnablePush) {
      btnEnablePush.innerHTML = '<i class="fa-solid fa-mobile-screen-button"></i> Enable Background Push';
      btnEnablePush.classList.remove('btn-success-pill');
      btnEnablePush.classList.add('btn-header-pill');
    }
    if (noticeTag) {
      noticeTag.innerHTML = '<i class="fa-solid fa-bell"></i> Notifications Ready to Enable';
    }
  }
}

/**
 * Prompt user for notification permission if state is default.
 * If user already denied, show clear explanation rather than repeating request.
 */
async function enableBackgroundPushNotifications() {
  if (!('Notification' in window) || !('serviceWorker' in navigator)) {
    showToast('Background Web Push is not supported in this browser environment.', 'warning');
    return;
  }

  if (Notification.permission === 'denied') {
    showToast('Notification permission is blocked. Please click the site settings/lock icon in your browser address bar to allow notifications.', 'warning');
    updateNotificationPermissionUIState();
    return;
  }

  try {
    const permission = await Notification.requestPermission();
    updateNotificationPermissionUIState();

    if (permission === 'granted') {
      showToast('Notifications granted! Registering Firebase push token...', 'info');
      await registerPushSubscriptionToken(true);
    } else if (permission === 'denied') {
      showToast('Notification permission was denied. You can enable it anytime in browser settings.', 'warning');
    }
  } catch (err) {
    console.error('Error requesting notification permission:', err);
    showToast('Error requesting notification permission.', 'danger');
  }
}

/**
 * Registers Service Worker & FCM token / Web Push subscription with the server
 */
async function registerPushSubscriptionToken(showToastNotice = true) {
  if (!state.currentUser) return;

  try {
    const swReg = await navigator.serviceWorker.register('/firebase-messaging-sw.js');
    await navigator.serviceWorker.register('/sw.js');
    const readyReg = await navigator.serviceWorker.ready;

    const res = await fetch(`${API_BASE_URL}/api/push/vapid-public-key`);
    const { publicKey } = await res.json();
    const applicationServerKey = urlBase64ToUint8Array(publicKey);

    let fcmToken = null;
    let pushSubscription = null;

    if (fcmMessaging) {
      try {
        fcmToken = await fcmMessaging.getToken({
          vapidKey: publicKey,
          serviceWorkerRegistration: swReg
        });
        console.log('[FCM] Token acquired:', fcmToken);
      } catch (fcmErr) {
        console.warn('[FCM] getToken fallback to standard WebPush subscription:', fcmErr);
      }
    }

    pushSubscription = await readyReg.pushManager.getSubscription();
    if (!pushSubscription) {
      pushSubscription = await readyReg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: applicationServerKey
      });
    }

    const saveRes = await fetch(`${API_BASE_URL}/api/push/subscribe`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        user_email: state.currentUser.email,
        subscription: pushSubscription ? pushSubscription.toJSON() : null,
        token: fcmToken,
        type: fcmToken ? 'fcm' : 'webpush'
      })
    });

    if (saveRes.ok) {
      if (showToastNotice) {
        showToast('Background FCM desktop notifications active!', 'info');
      }
    }
  } catch (err) {
    console.error('Error registering push subscription:', err);
  }
}

function startTaskMonitoringEngine() {
  initFirebaseMessaging();
  updateNotificationPermissionUIState();
  checkTargetTaskFromUrl();
}

/**
 * Handles navigation to specific task when notification is clicked
 */
function checkTargetTaskFromUrl() {
  const urlParams = new URLSearchParams(window.location.search);
  const taskId = urlParams.get('taskId');
  if (taskId) {
    setTimeout(() => {
      highlightTaskInUI(taskId);
    }, 500);
  }
}

function highlightTaskInUI(taskId) {
  if (!taskId) return;
  const taskElements = document.querySelectorAll('.task-item');
  taskElements.forEach(el => {
    if (el.getAttribute('data-task-id') === String(taskId)) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el.classList.add('task-highlight');
      setTimeout(() => el.classList.remove('task-highlight'), 3000);
    }
  });
}

// Service worker message listener for click focus navigation
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'NAVIGATE_TO_TASK' && event.data.taskId) {
      highlightTaskInUI(event.data.taskId);
    }
  });
}

function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  const typeClass = type === 'warning' ? 'toast-warning' : (type === 'danger' ? 'toast-danger' : '');
  const icon = type === 'warning' ? 'fa-bell' : (type === 'danger' ? 'fa-triangle-exclamation' : 'fa-circle-info');

  toast.className = `toast ${typeClass}`;
  toast.innerHTML = `
    <i class="fa-solid ${icon} toast-icon"></i>
    <div class="toast-body">${escapeHtml(message)}</div>
  `;

  DOM.toastContainer.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(50px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 6000);
}

function setupEventListeners() {
  const btnTestNotification = document.getElementById('btn-test-notification');
  if (btnTestNotification) {
    btnTestNotification.addEventListener('click', async () => {
      showToast('Testing FCM / Desktop Screen Notification...', 'info');
      if (Notification.permission === 'granted' && 'serviceWorker' in navigator) {
        const reg = await navigator.serviceWorker.ready;
        reg.showNotification('Task Reminder', {
          body: 'Your task "Complete Java Assignment" is scheduled in 1 hour.',
          icon: 'https://cdn-icons-png.flaticon.com/512/906/906334.png',
          badge: 'https://cdn-icons-png.flaticon.com/512/906/906334.png',
          tag: 'test-notification',
          requireInteraction: true,
          data: { url: '/' }
        });
      } else {
        enableBackgroundPushNotifications();
      }
    });
  }

  const btnEnablePush = document.getElementById('btn-enable-push');
  if (btnEnablePush) {
    btnEnablePush.addEventListener('click', () => {
      enableBackgroundPushNotifications();
    });
  }
}

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding).replace(/\-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}
