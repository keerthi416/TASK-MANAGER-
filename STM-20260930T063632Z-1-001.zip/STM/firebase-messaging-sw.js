/**
 * SMART TASK MANAGER - FIREBASE CLOUD MESSAGING SERVICE WORKER
 * Handles background FCM push notifications when the application tab/window is closed.
 */

// Import Firebase SDK scripts for Service Worker
importScripts('https://www.gstatic.com/firebasejs/10.8.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.8.0/firebase-messaging-compat.js');

// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSy_SmartTaskManager_FCM_Key",
  authDomain: "smart-task-manager.firebaseapp.com",
  projectId: "smart-task-manager",
  storageBucket: "smart-task-manager.appspot.com",
  messagingSenderId: "1035469915969",
  appId: "1:1035469915969:web:smarttaskmanager"
};

if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

const messaging = firebase.messaging();

// Handle FCM Background Messages
messaging.onBackgroundMessage((payload) => {
  console.log('[firebase-messaging-sw.js] Received background FCM payload:', payload);

  const title = payload.notification?.title || payload.data?.title || 'Task Reminder';
  const body = payload.notification?.body || payload.data?.body || 'You have a task update.';
  const taskId = payload.data?.taskId || payload.notification?.data?.taskId;
  const tag = payload.data?.tag || `task-${taskId || Date.now()}`;
  const targetUrl = payload.data?.url || (taskId ? `/?taskId=${encodeURIComponent(taskId)}` : '/');

  const notificationOptions = {
    body: body,
    icon: 'https://cdn-icons-png.flaticon.com/512/906/906334.png',
    badge: 'https://cdn-icons-png.flaticon.com/512/906/906334.png',
    tag: tag,
    requireInteraction: true,
    renotify: true,
    vibrate: [200, 100, 200],
    data: {
      url: targetUrl,
      taskId: taskId,
      timestamp: Date.now()
    },
    actions: [
      { action: 'open', title: 'Open Task Manager' },
      { action: 'dismiss', title: 'Dismiss' }
    ]
  };

  return self.registration.showNotification(title, notificationOptions);
});

// Handle Standard Web Push API Events
self.addEventListener('push', (event) => {
  console.log('[firebase-messaging-sw.js] Push event received.');

  let payload = {
    title: 'Task Reminder',
    body: 'You have a task update.',
    taskId: null,
    url: '/',
    tag: 'task-notification'
  };

  if (event.data) {
    try {
      const parsed = event.data.json();
      payload = { ...payload, ...parsed };
      if (parsed.notification) {
        payload.title = parsed.notification.title || payload.title;
        payload.body = parsed.notification.body || payload.body;
      }
      if (parsed.data) {
        payload.taskId = parsed.data.taskId || payload.taskId;
        payload.url = parsed.data.url || payload.url;
        payload.tag = parsed.data.tag || payload.tag;
      }
    } catch (err) {
      console.warn('[firebase-messaging-sw.js] Raw push text payload used:', err);
      payload.body = event.data.text() || payload.body;
    }
  }

  const title = payload.title || 'Task Reminder';
  const body = payload.body || 'You have a task update.';
  const taskId = payload.taskId;
  const targetUrl = payload.url || (taskId ? `/?taskId=${encodeURIComponent(taskId)}` : '/');
  const tag = payload.tag || `task-${taskId || Date.now()}`;

  const notificationOptions = {
    body: body,
    icon: 'https://cdn-icons-png.flaticon.com/512/906/906334.png',
    badge: 'https://cdn-icons-png.flaticon.com/512/906/906334.png',
    tag: tag,
    requireInteraction: true,
    renotify: true,
    vibrate: [200, 100, 200],
    data: {
      url: targetUrl,
      taskId: taskId,
      timestamp: Date.now()
    },
    actions: [
      { action: 'open', title: 'Open Task Manager' },
      { action: 'dismiss', title: 'Dismiss' }
    ]
  };

  event.waitUntil(
    self.registration.showNotification(title, notificationOptions)
  );
});

// Handle Notification Clicks
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (event.action === 'dismiss') {
    return;
  }

  const notificationData = event.notification.data || {};
  let targetUrl = notificationData.url || '/';
  if (notificationData.taskId && !targetUrl.includes('taskId=')) {
    targetUrl = `/?taskId=${encodeURIComponent(notificationData.taskId)}`;
  }

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      // Focus existing app tab if open
      for (const client of clientList) {
        if (client.url.includes(self.location.origin) && 'focus' in client) {
          if (notificationData.taskId && 'postMessage' in client) {
            client.postMessage({
              type: 'NAVIGATE_TO_TASK',
              taskId: notificationData.taskId
            });
          }
          return client.focus();
        }
      }
      // Open new tab/window if closed
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl);
      }
    })
  );
});
