const cron = require('node-cron');
const webpush = require('web-push');
const { dbAll, dbRun } = require('./db');
const { sendEmail } = require('./mailer');

function startScheduler() {
  console.log('[Scheduler] Background Task & FCM / Web Push Worker initialized (checking every 15 seconds)...');

  // Check database every 15 seconds for exact background notification timing
  cron.schedule('*/15 * * * * *', async () => {
    try {
      await checkTasksAndSendAlerts();
    } catch (err) {
      console.error('[Scheduler] Error during task check:', err.message);
    }
  });
}

async function sendWebPushAlert(userEmail, payloadData) {
  try {
    const subscriptions = await dbAll(`SELECT * FROM push_subscriptions WHERE user_email = ?`, [userEmail.toLowerCase()]);
    if (!subscriptions || subscriptions.length === 0) return;

    const payload = JSON.stringify(payloadData);

    for (const sub of subscriptions) {
      const pushSubscription = {
        endpoint: sub.endpoint,
        keys: {
          p256dh: sub.p256dh || '',
          auth: sub.auth || ''
        }
      };

      try {
        await webpush.sendNotification(pushSubscription, payload);
        console.log(`[Scheduler] Web Push / FCM alert sent to ${userEmail} (Endpoint: ${sub.endpoint.slice(0, 35)}...)`);
      } catch (pushErr) {
        console.error(`[Scheduler] Push Dispatch Warning (${sub.endpoint.slice(0, 35)}...):`, pushErr.statusCode || pushErr.message);

        // Status 410 (Gone) or 404 (Not Found) indicates push subscription has expired/been unsubscribed
        if (pushErr.statusCode === 410 || pushErr.statusCode === 404) {
          console.log(`[Scheduler] Removing expired/revoked push token from DB: ID ${sub.id}`);
          await dbRun(`DELETE FROM push_subscriptions WHERE id = ?`, [sub.id]);
        }
      }
    }
  } catch (err) {
    console.error('[Scheduler] Push notification dispatch failure:', err.message);
  }
}

async function checkTasksAndSendAlerts() {
  const now = new Date();
  const nowMs = now.getTime();

  // Fetch all pending/incomplete tasks
  const tasks = await dbAll(`SELECT * FROM tasks WHERE completed = 0`);
  if (!tasks || tasks.length === 0) return;

  for (const task of tasks) {
    const dueTime = new Date(task.due_timestamp).getTime();
    const diffMs = dueTime - nowMs;
    const diffMinutes = Math.floor(diffMs / (1000 * 60));

    // STAGE 1: 1-Hour Prior Notification
    // Title: Task Reminder
    // Message: Your task "{title}" is scheduled in 1 hour.
    if (diffMinutes >= 55 && diffMinutes <= 60 && task.notified_1h === 0) {
      const title = 'Task Reminder';
      const body = `Your task "${task.title}" is scheduled in 1 hour.`;

      await sendEmail({ to: task.user_email, subject: title, text: body });
      await sendWebPushAlert(task.user_email, {
        title: title,
        body: body,
        notification: {
          title: title,
          body: body,
          icon: 'https://cdn-icons-png.flaticon.com/512/906/906334.png'
        },
        data: {
          title: title,
          body: body,
          taskTitle: task.title,
          taskId: task.id,
          url: `/?taskId=${encodeURIComponent(task.id)}`,
          tag: `1h-${task.id}`
        },
        taskTitle: task.title,
        taskId: task.id,
        url: `/?taskId=${encodeURIComponent(task.id)}`,
        tag: `1h-${task.id}`
      });

      await dbRun(`UPDATE tasks SET notified_1h = 1 WHERE id = ?`, [task.id]);
      await dbRun(
        `INSERT INTO email_logs (user_email, subject, body, type) VALUES (?, ?, ?, ?)`,
        [task.user_email, title, body, 'reminder_1h']
      );
    }

    // STAGE 2: At Task Time Notification
    // Title: Task Due Now
    // Message: Your task "{title}" is due now.
    if (diffMinutes >= -1 && diffMinutes <= 0 && task.notified_due === 0) {
      const title = 'Task Due Now';
      const body = `Your task "${task.title}" is due now.`;

      await sendEmail({ to: task.user_email, subject: title, text: body });
      await sendWebPushAlert(task.user_email, {
        title: title,
        body: body,
        notification: {
          title: title,
          body: body,
          icon: 'https://cdn-icons-png.flaticon.com/512/906/906334.png'
        },
        data: {
          title: title,
          body: body,
          taskTitle: task.title,
          taskId: task.id,
          url: `/?taskId=${encodeURIComponent(task.id)}`,
          tag: `due-${task.id}`
        },
        taskTitle: task.title,
        taskId: task.id,
        url: `/?taskId=${encodeURIComponent(task.id)}`,
        tag: `due-${task.id}`
      });

      await dbRun(`UPDATE tasks SET notified_due = 1 WHERE id = ?`, [task.id]);
      await dbRun(
        `INSERT INTO email_logs (user_email, subject, body, type) VALUES (?, ?, ?, ?)`,
        [task.user_email, title, body, 'due_now']
      );
    }

    // STAGE 3: Overdue Notification
    // Title: Task Overdue
    // Message: Your task "{title}" is overdue.
    if (diffMs < 0 && task.notified_overdue === 0) {
      const title = 'Task Overdue';
      const body = `Your task "${task.title}" is overdue.`;

      await sendEmail({ to: task.user_email, subject: title, text: body });
      await sendWebPushAlert(task.user_email, {
        title: title,
        body: body,
        notification: {
          title: title,
          body: body,
          icon: 'https://cdn-icons-png.flaticon.com/512/906/906334.png'
        },
        data: {
          title: title,
          body: body,
          taskTitle: task.title,
          taskId: task.id,
          url: `/?taskId=${encodeURIComponent(task.id)}`,
          tag: `overdue-${task.id}`
        },
        taskTitle: task.title,
        taskId: task.id,
        url: `/?taskId=${encodeURIComponent(task.id)}`,
        tag: `overdue-${task.id}`
      });

      await dbRun(`UPDATE tasks SET status = 'overdue', notified_overdue = 1 WHERE id = ?`, [task.id]);
      await dbRun(
        `INSERT INTO email_logs (user_email, subject, body, type) VALUES (?, ?, ?, ?)`,
        [task.user_email, title, body, 'overdue_alert']
      );
    }
  }
}

module.exports = {
  startScheduler,
  checkTasksAndSendAlerts
};
