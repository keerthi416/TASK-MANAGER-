/**
 * SMART TASK MANAGER - SERVICE WORKER & FCM COMPATIBILITY
 * Real-time background Firebase Cloud Messaging & Web Push notification listener.
 * Enables background desktop/mobile push alerts when browser tabs are closed.
 */

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

// ==========================================
// 1. BACKGROUND PUSH EVENT LISTENER
// ==========================================
self.addEventListener('push', (event) => {
  console.log('[ServiceWorker] Push event received.');

  let payload = {
    title: 'Task Reminder',
    body: 'You have a task update.',
    taskId: null,
    url: '/',
    tag: 'task-notification'
  };

  if (event.data) {
    try {
      const data = event.data.json();
      payload = { ...payload, ...data };
      if (data.notification) {
        payload.title = data.notification.title || payload.title;
        payload.body = data.notification.body || payload.body;
      }
      if (data.data) {
        payload.taskId = data.data.taskId || payload.taskId;
        payload.url = data.data.url || payload.url;
        payload.tag = data.data.tag || payload.tag;
      }
    } catch (err) {
      console.warn('[ServiceWorker] Push data parse error, using text fallback:', err);
      payload.body = event.data.text() || 'You have a task update.';
    }
  }

  const title = payload.title || 'Task Reminder';
  const body = payload.body || 'You have a task update.';
  const taskId = payload.taskId;
  const targetUrl = payload.url || (taskId ? `/?taskId=${encodeURIComponent(taskId)}` : '/');
  const tag = payload.tag || `task-${taskId || Date.now()}`;

  const notificationOptions = {
    body: body,
    icon: 'https://cdn-icons-png.flaticon.com/512/906/906334.png',
    badge: 'https://cdn-icons-png.flaticon.com/512/906/906334.png',
    tag: tag,
    requireInteraction: true,
    renotify: true,
    vibrate: [200, 100, 200],
    data: {
      url: targetUrl,
      taskId: taskId,
      timestamp: Date.now()
    },
    actions: [
      { action: 'open', title: 'Open Task Manager' },
      { action: 'dismiss', title: 'Dismiss' }
    ]
  };

  const notificationPromise = self.registration.showNotification(
    title,
    notificationOptions
  );

  event.waitUntil(notificationPromise);
});

// ==========================================
// 2. NOTIFICATION CLICK HANDLER
// ==========================================
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const action = event.action;
  if (action === 'dismiss') {
    return;
  }

  const notificationData = event.notification.data || {};
  let targetUrl = notificationData.url || '/';
  if (notificationData.taskId && !targetUrl.includes('taskId=')) {
    targetUrl = `/?taskId=${encodeURIComponent(notificationData.taskId)}`;
  }

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url.includes(self.location.origin) && 'focus' in client) {
          if (notificationData.taskId && 'postMessage' in client) {
            client.postMessage({
              type: 'NAVIGATE_TO_TASK',
              taskId: notificationData.taskId
            });
          }
          return client.focus();
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl);
      }
    })
  );
});
